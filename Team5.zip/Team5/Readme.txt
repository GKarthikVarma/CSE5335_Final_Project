To Run the website plcae the contents of Team5_code in the htdocs of mysql database and follow the below steps

##############
Configure the website to connect to a database by edition the below file
background/dbh.php

Enter the appropriate mysql username and password for the website to be able to connect to the database.

##############
MYSQL DATABASE:
Create a table called "loginsystem"
Run the code from "loginsystem.sql" in loginsystem to generate the tables and populate them with data
