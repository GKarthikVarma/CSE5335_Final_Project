<?php

$dbServername = "127.0.0.1:3306";
$dbUsername = "root";
$dbPassword = "";
$dbName = "loginsystem";

$connection = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
?>
