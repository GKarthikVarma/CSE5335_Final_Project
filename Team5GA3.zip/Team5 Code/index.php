<?php
	include_once 'header.php';
?>

<body>
<div class='login-container'>
		<center>
		<div id='home-logo'>
		</div>

	</center>
</div>

<?php
	include_once 'footer.php';
?>
